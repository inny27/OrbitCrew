const CACHE_NAME = 'intask-v1';
const STATIC_ASSETS = [
  '/OrbitCrew/',
  '/OrbitCrew/index.html',
  'https://fonts.googleapis.com/css2?family=Press+Start+2P&family=Nunito:wght@400;600;700;800;900&display=swap'
];

// Install: cache core assets
self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => {
      return cache.addAll(STATIC_ASSETS).catch(() => {
        // Silently fail on optional assets
      });
    })
  );
  self.skipWaiting();
});

// Activate: clean old caches
self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys =>
      Promise.all(
        keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k))
      )
    )
  );
  self.clients.claim();
});

// Fetch: network first, cache fallback for app shell
self.addEventListener('fetch', event => {
  const url = new URL(event.request.url);

  // Always network-first for Firebase (auth/Firestore)
  if (url.hostname.includes('firebaseapp.com') ||
      url.hostname.includes('googleapis.com') ||
      url.hostname.includes('firebaseio.com') ||
      url.hostname.includes('gstatic.com') ||
      url.hostname.includes('maplestory.io') ||
      url.hostname.includes('youtube.com') ||
      url.hostname.includes('img.youtube.com')) {
    return; // Let browser handle normally
  }

  // For same-origin app requests: stale-while-revalidate
  if (url.origin === self.location.origin) {
    event.respondWith(
      caches.open(CACHE_NAME).then(cache =>
        cache.match(event.request).then(cached => {
          const networkFetch = fetch(event.request).then(response => {
            if (response.ok) cache.put(event.request, response.clone());
            return response;
          }).catch(() => cached);
          return cached || networkFetch;
        })
      )
    );
  }
});

// Handle push notifications (future use)
self.addEventListener('push', event => {
  if (!event.data) return;
  const data = event.data.json();
  self.registration.showNotification(data.title || 'InTask', {
    body: data.body || '',
    icon: 'https://maplestory.io/api/GMS/255/mob/100100/render/stand',
    badge: 'https://maplestory.io/api/GMS/255/item/2000000/icon',
    data: data
  });
});
